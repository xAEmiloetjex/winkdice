module.exports = function() {
  return {name: 'deprecated'};
};
