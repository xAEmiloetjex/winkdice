/* tslint:disable quotemark */
/* TODO: rework this so that it has single quotes */
export const {$ doc.serviceName $} = {$ doc.value | json $};
