export const operator = () => {};
