// This is for the production site, which is hosted at https://angular.io
export const environment = {
  gaId: 'UA-36380079-2', // Production id
  production: true,
  mode: 'stable'
};
