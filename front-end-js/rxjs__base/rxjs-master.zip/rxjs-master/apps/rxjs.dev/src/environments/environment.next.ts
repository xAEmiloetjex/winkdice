// This is for the staging site, which is hosted at https://next.angular.io (and https://aio-staging.firebaseapp.org)
export const environment = {
  gaId: 'UA-36380079-2', // Production id (since it is linked from the main site)
  production: true,
  mode: 'next'
};
