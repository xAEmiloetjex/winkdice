var welcomeText = (
  ' ____           _ ____      \n' +
  '|  _ \\ __  __  | / ___|    \n' +
  '| |_) |\\ \\/ /  | \\___ \\  \n' +
  '|  _ <  >  < |_| |___) |    \n' +
  '|_| \\_\\/_/\\_\\___/|____/ \n' +
  '\nTo start experimenting with RxJS: https://stackblitz.com/edit/rxjs\n'
);
if (console.info) {
  console.info(welcomeText);
} else {
  console.log(welcomeText);
}
